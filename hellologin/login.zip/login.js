"use strict";

var express = require('express');
var session = require('express-session');
var bodyParser = require('body-parser');
var path = require('path');
var url = require('url');

var fs = require("fs");
const { response } = require('express');
const { SSL_OP_SSLEAY_080_CLIENT_DH_BUG } = require('constants');

function xread(file) {
    return fs.readFileSync(file).toString();
}

var app = express();

app.use(bodyParser.text({type: 'text/html'}));
app.use(express.static(path.join(__dirname, '/assets')));

app.use(session({
    secret: 'secret',
    resave: true,
    saveUninitialized: true
}));
app.use(bodyParser.urlencoded({extended : true}));
app.use(bodyParser.json());


app.get('/', function(request, response) {
    response.sendFile(path.join(__dirname + '/login.html'));
});


app.get('/register', function(request, response) {
    response.sendFile(path.join(__dirname + '/register.html'));
});


//assuming read looks like
// user1:pw1\nuser2:pw2\n

app.post('/reg', function(request, response) {
    var username = request.body.username;
    var password = request.body.password;
    var password2 = request.body.password2;
    console.log(username, password, password2);
    

    if (username && password && password2) {
        if (password !== password2) {
            response.send("Passwords do not match");
            return;
        }

        //check if username is already taken
        var contents = JSON.parse(fs.readFileSync("list.json"));
        console.log(contents[username]);

        if (contents[username]) {
            //username has been taken
            response.send("Username is Taken Already");    
            return;
        }
        if (username.length < 3 || username.length > 50) {
            response.send("Username must be between 3 and 50 characters");
            return;
        }
        if (!username[0].match(/^[0-9a-z]+$/i)) {
            response.send("Username must begin with an alphanumeric character");
            return;
        }


        //create the new account with password
        contents[username] = password;
        fs.writeFileSync("list.json", JSON.stringify(contents));


        //set the stats
        var k = JSON.parse(fs.readFileSync('stats.json'));
        k.push([username, 0, 0, 0, 0, 0, 0]);
        fs.writeFileSync('stats.json', JSON.stringify(k));
        response.redirect('/');
        return;


    }
    response.send("Please enter Usernsme and/or Password!");
});

app.post('/auth', function(request, response) {
    var username = request.body.username;
    var password = request.body.password;
    if (username && password) {
        var contents = JSON.parse(xread("list.json"));
        if (contents[username] == password) {
   
            request.session.loggedin = true;
            request.session.username = username;
            response.redirect('/home');
            return;
            
        }

        response.send('Incorrect Username and/or Password!');
        response.end();

    } else {
        response.send('Please enter Username and/or Password!');
        response.end();
    }
});


app.get('/home', function(request, response) {
    if (request.session.loggedin) {
        response.redirect('/math');
    } else {
        response.sendFile(`${__dirname}/please_log_in.html`);
    }
    response.end();

});


app.get('/math', function(request, response) {
    var stats = JSON.parse(fs.readFileSync('stats.json'));
    var fraction_data = [];
    var pf_data = [];
    var lcm_data = [];
    for (var i = 0; i < stats.length; i++) {
        fraction_data.push([stats[i][0], stats[i][1], stats[i][2]]);
        pf_data.push([stats[i][0], stats[i][3], stats[i][4]]);
        lcm_data.push([stats[i][0], stats[i][5], stats[i][6]]);
    }

    fraction_data.sort((a, b) => a[1] - b[1]);
    pf_data.sort((a, b) => a[1] - b[1]);
    lcm_data.sort((a, b) => a[1] - b[1]);


    
    var fraction_text = "";
    var pf_text = "";
    var lcm_text = "";

    var fraction_text2 = "";
    var pf_text2 = "";
    var lcm_text2 = "";
    
    for (var i = 0; i < stats.length; i++) {
        var f = fraction_data[i];
        var p = pf_data[i];
        var l = lcm_data[i];

        fraction_text = `<tbody><tr><td>${f[0]}</td></tr></tbody>` + fraction_text;
        pf_text = `<tbody><tr><td>${p[0]}</tr></td></tbody>` + pf_text;
        lcm_text = `<tbody><tr><td>${l[0]}</tr></td></tbody>` + lcm_text;

        fraction_text2 = `<tbody><tr><td> :${f[1]}</td></tr></tbody>` + fraction_text2;
        pf_text2 = `<tbody><tr><td> :${p[1]}</tr></td></tbody>` + pf_text2;
        lcm_text2 = `<tbody><tr><td> : ${l[1]}</tr></td></tbody>` + lcm_text2;
        
        
    }
    var htmlstuff = fs.readFileSync('index.html').toString();
    htmlstuff = htmlstuff.replace('<tr>fractions</tr>', fraction_text);
    htmlstuff = htmlstuff.replace('<tr>lcm</tr>', lcm_text);
    htmlstuff = htmlstuff.replace('<tr>pf</tr>', pf_text);

    htmlstuff = htmlstuff.replace('<tr>fractions2</tr>', fraction_text2);
    htmlstuff = htmlstuff.replace('<tr>lcm2</tr>', lcm_text2);
    htmlstuff = htmlstuff.replace('<tr>pf2</tr>', pf_text2);

    response.send(htmlstuff);


});


app.get('/mathlcm', function(request, response) {
    if (request.session.loggedin) {
        var x = fs.readFileSync('least_common_multiple.html').toString();
        x = x.replace(`id="username">`, `id="username">${request.session.username}`);
        
        response.send(x);
    }
    else {
        response.sendFile(`${__dirname}/please_log_in.html`)
    }
});


app.get('/mathfactor', function(request, response) {
    if (request.session.loggedin) {
        var x = fs.readFileSync('prime_factorization.html').toString();
        x = x.replace(`id="username">`, `id="username">${request.session.username}`);
        
        response.send(x);
    }
    else {
        response.sendFile(`${__dirname}/please_log_in.html`)
    }
});

app.get('/mathfractions', function(request, response) {
    if (request.session.loggedin) {
        var x = fs.readFileSync('add_fractions.html').toString();
        x = x.replace(`id="username">`, `id="username">${request.session.username}`);
        
        response.send(x);
    }
    else {
        response.sendFile(`${__dirname}/please_log_in.html`);
    }
});






// send request via index.html
app.post('/scores', async (request, response) => {
    try {

        let query = url.parse(request.url, true).query;

        const username = query['username'];
        const type = query['type'];
        const correct = query['correct'] == 1;
        console.log(username, type, correct);

        var obj = JSON.parse(fs.readFileSync('stats.json'));
        for (var i = 0; i < obj.length; i++) {
            if (obj[i][0] === username) {
                if (type === 'fraction') {
                    if (correct) {
                        obj[i][1]++;
                    }
                    else {
                        obj[i][2]++;
                    }
                    console.log('fraction');
                }
                else if (type === 'pf') {
                    if (correct) {
                        obj[i][3]++;
                    }
                    else {
                        obj[i][4]++;
                    }
                    console.log('pf')
                }
                else if (type === 'lcm') {
                    if (correct) {
                        obj[i][5]++;
                    }
                    else {
                        obj[i][6]++;
                    }
                    console.log('lcm');
				}
				fs.writeFileSync('stats.json', JSON.stringify(obj));
                break;
            }
        }


        if (obj) {
            response.status(200).send('sent successfully');
        } 
        else {
            response.writeHead(InternalServerError);
            response.write('failed to send');
        }  
    }
    catch(err) {
        console.log(username, type, correct);
        response.writeHead(InternalServerError);
        response.write('failed to send');
    }
});

app.listen(80);